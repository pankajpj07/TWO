import { WithLayout } from "../component/layout";

const HomePage = () =>
    <>
        Home Page
    </>;

export default WithLayout( HomePage );
